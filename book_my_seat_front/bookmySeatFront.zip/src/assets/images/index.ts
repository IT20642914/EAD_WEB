export { default as logo } from './logo_transparent.png'

