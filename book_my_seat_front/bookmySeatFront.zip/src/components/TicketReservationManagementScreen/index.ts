
export { default as GeneralInformationTicket } from './GeneralInformationTicket/GeneralInformationTicket';
export { default as DetailedInformationTicket } from './DetailedInformationTicket/DetailedInformationTicket';
